<?php require_once "../Login/controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email' AND user_type = 0";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: login.php');
}
?>
<?php include("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Bienvenida</title>
</head>
<body>
	<div class="container">
		<div class="center">
            <div class="box">
			    <h1>BIENVENIDO:<br> <?php echo $fetch_info['name'] ?></h1>
                <p></p>
                <p class="lead">Precione continuar para comenzar a administrar</p>
		    	<a class="btn btn-primary btn-lg" href="../ejemplophp/posts.php" role="button">Continuar</a>
    		</div>
	</div>
</body>
</html>
                
