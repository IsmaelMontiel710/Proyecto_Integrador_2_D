
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" 
integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

<style>
        body {
			background-image: url('https://www.xtrafondos.com/wallpapers/nebulosa-3334.jpg');
		}
        h1{
            font-size: 56px;
        }

		.container {
			display: flex;
			align-items: center;
			justify-content: center;
			height: 100vh;
			width: 100%;
		}
        .box {
			width: 700px;
			height: 350px;
			background-color: rgba(255, 255, 255, 0.1);
			/*border: 1px solid #ccc;*/
			border-radius: 10px;
			padding: 30px 35px;
			border-radius: 5px;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		}
		.center {
			text-align: center;
			color: white;
		}
	</style>