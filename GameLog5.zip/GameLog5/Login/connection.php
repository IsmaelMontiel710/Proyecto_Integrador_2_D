<?php 
$con = mysqli_connect('localhost', 'root', '', 'login-php');
?>