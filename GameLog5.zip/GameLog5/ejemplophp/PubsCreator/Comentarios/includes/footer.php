<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="../Comentarios/assets/custom.js"></script>
<script type="text/javascript" src="../../../d/js/header.js"></script>
<script  src="../../../d/js/caja_seccionv.js"></script>
<script  src="../../../d/js/index.js"></script>
</body>
</html>