const box = document.querySelector(".box");

box.addEventListener("mouseenter", () => {
  box.style.width = "80%";
  box.style.height = "250px";
  box.style.borderColor = "black";
});

box.addEventListener("mouseleave", () => {
  box.style.width = "70%";
  box.style.height = "200px";
  box.style.borderColor = "black";
});
const box2 = document.querySelector(".box2");

box.addEventListener("mouseenter", () => {
  box.style.width = "80%";
  box.style.height = "250px";
  box.style.borderColor = "black";
});

box.addEventListener("mouseleave", () => {
  box.style.width = "70%";
  box.style.height = "200px";
  box.style.borderColor = "black";
});
const box3 = document.querySelector(".box3");

box.addEventListener("mouseenter", () => {
  box.style.width = "80%";
  box.style.height = "250px";
  box.style.borderColor = "black";
});

box.addEventListener("mouseleave", () => {
  box.style.width = "70%";
  box.style.height = "200px";
  box.style.borderColor = "black";
});
const box4 = document.querySelector(".box4");

box.addEventListener("mouseenter", () => {
  box.style.width = "80%";
  box.style.height = "250px";
  box.style.borderColor = "black";
});

box.addEventListener("mouseleave", () => {
  box.style.width = "70%";
  box.style.height = "200px";
  box.style.borderColor = "black";
});

