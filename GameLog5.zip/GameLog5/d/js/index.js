window.sr = ScrollReveal();

    sr.reveal('.na', {
        duration: 3000,
        origin: 'bottom',
        distance: '-100px'
    });

    sr.reveal('.ri', {
        duration: 4000,
        origin: 'left',
        distance: '-80px'
    });
    sr.reveal('.le', {
        duration: 4000,
        origin: 'right',
        distance: '-80px'
    });

    sr.reveal('.pde', {
        duration: 4000,
        origin: 'bottom',
        distance: '80px'
    });

