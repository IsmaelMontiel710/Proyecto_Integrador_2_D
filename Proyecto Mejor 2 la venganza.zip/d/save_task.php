<?php

include('db.php');

if (isset($_POST['save_task'])) {
  $title = $_POST['title'];
  $subtitle = $_POST['subtitle'];
  $description = $_POST['description'];
  $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
  $query = "INSERT INTO task(title, subtitle, description, image) VALUES ('$title','$subtitle', '$description','$image')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Saved Successfully';
  $_SESSION['message_type'] = 'success';
  header('Location: posts.php');

}

?>
