<?php include("db.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="css/fondo-texto.css">
    <link rel="stylesheet" href="https://bootswatch.com/4/yeti/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/5f897f84ba.js" crossorigin="anonymous"></script>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body class="body">
  <main class="container p-4 text-light">
    <div class="row text-light">
      <div class="col-md-4">
        <!-- MESSAGES -->

        <?php if (isset($_SESSION['message'])) { ?>
        <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
          <?= $_SESSION['message']?>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php session_unset(); } ?>

        <!-- ADD TASK FORM -->
        <div class="card card-body">
          <form action="save_task.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
              <input type="text" name="title" class="form-control" placeholder="Task Title" autofocus>
            </div>
            <div class="form-group">
              <input type="text" name="subtitle" class="form-control" placeholder="Task Subtitle" autofocus >
            </div>
            <div class="form-group">
              <textarea name="description" rows="2" class="form-control" placeholder="Task Description"></textarea>
            </div>
            <div class="">
              <p class="text-dark">Ingrese una Imagen <input type="file" name="image"></p>
            </div>
            <input type="submit" name="save_task" class="btn btn-success btn-block" value="Save Task">
          </form>
        </div>
      </div>
      <div class="col-md-8">
        <table class="table table-bordered text-light text-center">
          <thead>
            <tr>
              <th>Title</th>
              <th>Subtitle</th>
              <th>Description</th>
              <th>Created At</th>
              <th>Imagen</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

            <?php
            $query = "SELECT * FROM task";
            $result_tasks = mysqli_query($conn, $query);    
            while($row = mysqli_fetch_assoc($result_tasks)) { ?>
            <tr>
              <td><?php echo $row['title']; ?></td>
              <td><?php echo $row['subtitle']; ?></td>
              <td><?php echo $row['description']; ?></td>
              <td><?php echo $row['created_at']; ?></td>
              <td><?php echo $row['image']="<img width='200px' height='200px' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?></td>
              <td class="text-center">
                <a href="edit.php?id=<?php echo $row['Id']?>" class="btn btn-secondary">
                  <i class="fas fa-marker"></i>
                </a>
                <a href="delete_task.php?id=<?php echo $row['Id']?>" class="btn btn-danger">
                  <i class="far fa-trash-alt"></i>
                </a>
                <a href="Vision.php?id=<?php echo $row['Id']?>" class="btn btn-success">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                    <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                    <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                  </svg>
                </a>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
    <div class="espacio"></div>
    <div id="footer">
        <?php include "Parte/footer.html"?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>
