<?php include("db.php"); ?>


<main><!--es el contenido de toda la pagina principal-->
  <div class="col-12">
    <div id="myCarousel" class="carousel slide" data-bs-ride="carousel"><!--desde aqui empieza el carrusel-->
      <div class="carousel-indicators"><!--es para que se mueva solo con la clase active es el que inicia cuando se ejcuta pa pagina-->
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" aria-label="Slide 1"  class="active"></button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"  class=""></button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"  class=""></button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="3" aria-label="Slide 4"  class="" aria-current="true"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active container img">
          <?php
            $query = "SELECT * FROM task WHERE id=1";
             $result_tasks = mysqli_query($conn, $query);    
              $row = mysqli_fetch_assoc($result_tasks);?>
          <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <figure class="zoomca ">
              <?php echo $row['image']="<img class='ma' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
            </figure>
          </a>
          <div class="carousel-caption text-center">
              <h2 ><?php echo $row['title']; ?></h2>
              <p ><?php echo $row['subtitle']; ?></p>
          </div>
        </div>
        <div class="carousel-item">
          <?php
            $query = "SELECT * FROM task WHERE id=2";
             $result_tasks = mysqli_query($conn, $query);    
            $row = mysqli_fetch_assoc($result_tasks);?>
          <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <figure class="zoomca ">
            <?php echo $row['image']="<img class='ma' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
            </figure>
          </a>
          <div class="carousel-caption text-center">
            <h2 ><?php echo $row['title']; ?></h2>
            <p ><?php echo $row['subtitle']; ?></p>
          </div>
        </div>

        <div class="carousel-item">
          <?php
            $query = "SELECT * FROM task WHERE id=3";
             $result_tasks = mysqli_query($conn, $query);    
              $row = mysqli_fetch_assoc($result_tasks);?>
          <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <figure class="zoomca ">
            <?php echo $row['image']="<img class='ma' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
            </figure>
          </a>
          <div class="carousel-caption text-center">
            <h2 ><?php echo $row['title']; ?></h2>
            <p ><?php echo $row['subtitle']; ?></p>
          </div>
        </div>

        <div class="carousel-item">
          <?php
            $query = "SELECT * FROM task WHERE id=4 ";
             $result_tasks = mysqli_query($conn, $query);    
              $row = mysqli_fetch_assoc($result_tasks);?>
          <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <figure class="zoomca ">
            <?php echo $row['image']="<img class='ma' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
            </figure>
          </a>
          <div class="carousel-caption text-center">
            <h2 ><?php echo $row['title']; ?></h2>
            <p ><?php echo $row['subtitle']; ?></p>
          </div>
        </div>
      </div>

        <!--Son los botones de accion al cambiar de pagina haga la funcion(funcion de boostrap)-->
      <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden"></span>
      </button>

      <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden"></span>
      </button>
    </div>
    <br>
  </div>

  <!--es el tabla se podria decir de las publicaciones de abajo del carrusel-->
  <div class="row container">
    <div class="col-2"><!--es el epacio entre una-->
    </div>
    <div class="col-3 text-center"><!--es como un cuadro que tiene 2 columnas -->
      <div class="col-11 bg-light text-dark rounded borde"><!--de esas 2 columas esta dividido en 11 columnas con sus respectivos bordes-->
        <br>
        <a href="Publicaciones.php"><!--cuando se acerca el mouse es un link y hace zoom-->
          <figure class="zoom">
            <?php
              $query = "SELECT * FROM task WHERE id=1 ";
              $result_tasks = mysqli_query($conn, $query);    
                $row = mysqli_fetch_assoc($result_tasks);?>
            <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <?php echo $row['image']="<img class='img' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
          </figure>
        </a>
        <h2 class="text"><?php echo $row['title']; ?></h2><!--el titulo-->
        <p class=""><?php echo $row['subtitle']; ?></p><!--texto-->
        <div class="text-center">
          <a href="publicaciones.php?id=<?php echo $row['Id']?>" class="btn btn-outline-dark">ver mas...</a><!--todavia no lo manda a ningun link-->
        </div>
        <br>
      </div>
    </div>

    <div class=" col-3 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <a href="Publicaciones.php">
          <figure class="zoom">
            <?php
              $query = "SELECT * FROM task WHERE id=2 ";
              $result_tasks = mysqli_query($conn, $query);    
                $row = mysqli_fetch_assoc($result_tasks);?>
            <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <?php echo $row['image']="<img class='img' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
          </figure>
        </a>
        <h2 class="text"><?php echo $row['title']; ?></h2>
        <p class=""><?php echo $row['subtitle']; ?></p>
        <div class="text-center">
          <a href="publicaciones.php?id=<?php echo $row['Id']?>" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>

    <div class=" col-3 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <br>
        <a href="Publicaciones.php">
          <figure class="zoom">
            <?php
              $query = "SELECT * FROM task WHERE id=3 ";
              $result_tasks = mysqli_query($conn, $query);    
                $row = mysqli_fetch_assoc($result_tasks);?>
            <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <?php echo $row['image']="<img class='img' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
          </figure>
        </a>
        <h2 class="text"><?php echo $row['title']; ?></h2>
        <p class=""><?php echo $row['subtitle']; ?></p>
        <div class="text-center">
          <a href="publicaciones.php?id=<?php echo $row['Id']?>" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
      <div class="col-2"><!--es el epacio entre una-->
      </div>
    </div>
  </div>
  <br>
  <div class="row container">
    <div class="col-3"><!--es el epacio entre una-->
    </div>
    <div class="col-3 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <a href="Publicaciones.php">
          <figure class="zoom">
            <?php
              $query = "SELECT * FROM task WHERE id=4 ";
              $result_tasks = mysqli_query($conn, $query);    
                $row = mysqli_fetch_assoc($result_tasks);?>
            <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <?php echo $row['image']="<img class='img' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
          </figure>
        </a>
        <h2 class="text"><?php echo $row['title']; ?></h2>
        <p class=""><?php echo $row['subtitle']; ?></p>
        <div class="text-center">
          <a href="publicaciones.php?id=<?php echo $row['Id']?>" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>

    <div class="col-3 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <br>
        <a href="Publicaciones.php">
          <figure class="zoom">
            <?php
              $query = "SELECT * FROM task WHERE id=5 ";
              $result_tasks = mysqli_query($conn, $query);    
                $row = mysqli_fetch_assoc($result_tasks);?>
            <a href="publicaciones.php?id=<?php echo $row['Id']?>">
            <?php echo $row['image']="<img class='img' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
          </figure>
        </a>
        <h2 class="text"><?php echo $row['title']; ?></h2>
        <p class=""><?php echo $row['subtitle']; ?></p>
        <div class="text-center">
          <a href="publicaciones.php?id=<?php echo $row['Id']?>" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>
    <div class="col-3"><!--es el epacio entre una-->
    </div>
  </div>
</main>
<br>