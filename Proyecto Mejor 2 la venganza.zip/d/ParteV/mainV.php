<main>
  <?php
      include("db.php");
      $title = '';
      $description= '';

      if  (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "SELECT * FROM task WHERE id=$id";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
          $row = mysqli_fetch_array($result);
          $title = $row['title'];
          $subtitle = $row['subtitle'];
          $description = $row['description'];
          $image = $row['image'];
        }
      }
  ?>
  <div class="pe">
    <h1 class="text-center">Visualizacion del Carrusel</h1>
  </div>
  <div class="col-12">
    <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" aria-label="Slide 1" class="active"></button>
        </div>
        
        <div class="carousel-inner">
          <div class="carousel-item active container img">
            <a href="">
              <figure class="zoomca ">
                <?php echo $row['image']="<img  class='container ma' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
              </figure>
            </a>
            <div class="carousel-caption text-center">
                <?php echo $title; ?>
                <br>
                <?php echo $subtitle;?>
                <!--aqui llamo el titulo y el subtitulo-->
            </div>
          </div>
        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden"></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden"></span>
        </button>
    </div>
    <br>
  </div>
  <div class="pe">
    <h1 class="text-center">Visualizacion de la caja</h1>
  </div>
  <div class="row container ">
    <div class="col-4">
    </div>

    <div class="col-2 text-center Container">
      <div class="col-11 bg-light text-dark rounded borde">
        <br>
        <a href="">
          <figure class="zoom">
            <?php
              if  (isset($_GET['id'])) {
                $id = $_GET['id'];
                $query = "SELECT * FROM task WHERE id=$id";
                $result = mysqli_query($conn, $query);
                if (mysqli_num_rows($result) == 1) {
                  $row = mysqli_fetch_array($result);
                  $title = $row['title'];
                  $subtitle = $row['subtitle'];
                  $description = $row['description'];
                  $image = $row['image'];
                }
              }
            ?>
            <?php echo $row['image']="<img  class='container' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>

            <!--aqui se ve la imagen de la caja-->
          </figure>
        </a>
          <?php echo $title; ?>
          <br>
          <?php echo $subtitle;?>
        <!--aqui va el titulo y el subtitulo-->
        <div class="text-center">
          <a class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>
    
    <div class=" col-2 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <a href="">
          <figure class="zoom">
            <?php
              if  (isset($_GET['id'])) {
                $id = $_GET['id'];
                $query = "SELECT * FROM task WHERE id=$id";
                $result = mysqli_query($conn, $query);
                if (mysqli_num_rows($result) == 1) {
                  $row = mysqli_fetch_array($result);
                  $title = $row['title'];
                  $subtitle = $row['subtitle'];
                  $description = $row['description'];
                  $image = $row['image'];
                }
              }
            ?>
            <?php echo $row['image']="<img  class='container' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
            <!--aqui va la imagen-->
          </figure>
        </a>
        <?php echo $title; ?>
        <br>
        <?php echo $subtitle;?>
        <!--aqui va el titulo y el subtitulo-->
        <div class="text-center">
          <a class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>
    <div class="col-1"></div>
  </div>
  <div class="pe">
    <h1 class="text-center">Visualizacion en los Posts</h1>
  </div>
  <div class="text-center text-light">
    <!--el texto de la post-->
    <h1><?php echo $title; ?></h1>
    <?php
      if  (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "SELECT * FROM task WHERE id=$id";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
          $row = mysqli_fetch_array($result);
          $title = $row['title'];
          $description = $row['description'];
          $image = $row['image'];
        }
      }
    ?>
    <?php echo $row['image']="<img  width='300px' height='300px' class='container' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
    <h3><?php echo $subtitle; ?></h3>
    <p><?php echo $description;?></p>
  </div>
</main>
<br>