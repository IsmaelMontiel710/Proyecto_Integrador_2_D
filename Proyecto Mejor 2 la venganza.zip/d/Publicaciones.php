<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitante</title>
    <link rel="stylesheet" href="css/fondo-texto.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body class="body">
    <div class="row">
        <div class="bo ">
            <?php include "Parte/header.html"?>
        </div>
    </div>
    <div class="con text-light">
        <h1 class="text-center ">POSTS</h1>
    </div>
    <?php
      include("db.php");
      $title = '';
      $description= '';

      if  (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "SELECT * FROM task WHERE id=$id";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
          $row = mysqli_fetch_array($result);
          $title = $row['title'];
          $subtitle = $row['subtitle'];
          $description = $row['description'];
          $image = $row['image'];
        }
      }
    ?>
    <div class="text-center text-light">
        <!--el texto de la post-->
        <h1><?php echo $title; ?></h1>
            <?php echo $row['image']="<img  width='300px' height='300px' class='container' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
        <br>
        <h3><?php echo $subtitle; ?></h3>
        <?php echo $description;?>
    </div>
    <div class="espacio"></div>
    <div>
        <?php include "Parte/footer.html"?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>