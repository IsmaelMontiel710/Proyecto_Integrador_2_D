<?php
    $con=mysqli_connect('localhost','root','','posts') or die('Error en la conexion servidor');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <title>Página de visitante</title>
  <link rel="stylesheet" type="text/css" href="cssVisitante.css">
  <link rel="stylesheet" type="text/css" href="animaciones.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">  
  <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/carousel/">
  <!-- Bootstrap core CSS -->
    <!-- Favicons -->
  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>
  <!-- Custom styles for this template -->
</head>

<body class="body">
  <header>
    <nav class="navbar navbar-expand-lg menu">
        <a href="visitante.php"><img src="Imagenes/logo.jpg" alt="" class="logo"></a>

        <button class="navbar-toggler btn-menu" id="btn-menu" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i>
        </button>
        <h3 class="fw-bolder">GAMELOG</h3>
        <div class="personaje">
        </div>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link ">|</a></li>
                <li class="nav-item"><a class="nav-link link-success" href="../ADMINISTRADOR/sidenavigation.php">ADMIN</a></li>
                <li class="nav-item"><a class="nav-link">|</a></li>
                <li class="nav-item"><a class="nav-link link-primary" href="">Blog</a></li>
                <li class="nav-item"><a class="nav-link">|</a></li>
                <li class="nav-item"><a class="nav-link link-light" href="">Noticias</a></li>
                <li class="nav-item"><a class="nav-link">|</a></li>
                <li class="nav-item"><a class="nav-link link-warning" href=#footer>Acerca de Nosotros</a></li>
                <li class="nav-item"><a class="nav-link">|</a></li>
                <li class="nav-item"><a class="nav-link link-danger " href="">Iniciar Sesion</a></li>
                <li class="nav-item"><a class="nav-link">|</a></li>
                <li class="nav-item"><a class="nav-link link-info" href="">Resgistrarse</a></li>
                <li class="nav-item"><a class="nav-link">|</a></li>
            </ul>
        </div>
    </nav>
  </header>
  <div class="p-4 p-md-5 mb-4   col-7">
    <div class="container"> <h1>Noticias Hot</h1></div>

    <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="" aria-label="Slide 1">
        </button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3" class="active" aria-current="true"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <form action="footer.html">
            <button>
            <div class="card " class="col-md-3" style="width: 18rem;">
              <img src="Imagenes/blo1.png" class="card-img-top">
              <div class="card-body">
                <h5 class="card-title">perro</h5>
                <p class="card-text">Hola que haces</p>
                <!--<a href="#blo1" class="btn">ver mas...</a>-->
              </div>
              <br>
            </div>
            </button>
          </form>
          <br>
          <br>
          <div class="carousel-caption ">
          </div>
        </div>
        <div class="carousel-item">
        <form action="footer.html">
            <button>
            <div class="card " class="col-md-3" style="width: 18rem;">
              <img src="Imagenes/blo1.png" class="card-img-top">
              <div class="card-body">
                <h5 class="card-title">perro</h5>
                <p class="card-text">Hola que haces</p>
                <!--<a href="#blo1" class="btn">ver mas...</a>-->
              </div>
              <br>
            </div>
            </button>
          </form>
          <br>
          <br>
          <div class="carousel-caption ">
          </div>
        </div>
        <div class="carousel-item ">
          <form action="footer.html">
            <button >
            <div class="card " class="col-md-3" style="width: 18rem;">
              <img src="Imagenes/blo1.png" class="card-img-top">
              <div class="card-body">
                <h5 class="card-title">perro</h5>
                <p class="card-text">Hola que haces</p>
                <!--<a href="#blo1" class="btn">ver mas...</a>-->
              </div>
              <br>
            </div>
            </button>
          </form>
          <br>
          <br>
          <div class="carousel-caption ">
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden"></span>
      </button>
    </div>
  </div>
  <br>
  <main class="container">
      <br>
      <!--la creacion de los texto perro y los cuadros-->
    <div class="row">
        <!--con la class card y accordion-iten crea el cuadro de texto-->
        <div class="card " class="col-md-3" style="width: 18rem;">
          <img src="Imagenes/blo1.png" class="card-img-top">
          <div class="card-body">
            <h5 class="card-title">perro</h5>
            <p class="card-text">Hola que haces</p>
            <!--<a href="#blo1" class="btn">ver mas...</a>-->
          </div>
          <br>
        </div>
        
        <div class="col-md-1"></div>

        <div class="card" class="col-md-3" style="width: 18rem;">
          <img src="Imagenes/blo2.png" >
          <div class="card-body">
            <h5 class="card-title">perro</h5>
            <p class="card-text">Hola que haces</p>
          </div>
          <!--<div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
              <h2 class="accordion-header" id="flush-headingOne">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                </button>
              </h2>
              <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                <div >
                  <?php
                    #$sql="SELECT * FROM Post ";
                    #$result=mysqli_query($con,$sql);
                    #$mos=mysqli_fetch_array($result)
                  ?>
                  <tr>
                      <td>
                        <?php #echo $mos['Texto']?>
                      </td>
                  </tr>
                </div>
              </div>
            </div>
            <br>
          </div>-->
          <br>
        </div>
        <div class="col-md-1"></div>


        <div class="card" class="col-md-3" style="width: 18rem;">
          <img src="Imagenes/blo3.png" class="img-fluid" alt="...">
            <div class="card-body">
              <h5 class="card-title">perro</h5>
              <p class="card-text">Hola que haces</p>
            </div>
        </div>
        <br>
        <!--Fin de los textos perro-->
        <div class="blo1 container" id="blo1">
          <br>
        </div>
    </div>
    <br>
    <div class="text-center container row" >
      <div class="col-md-5"> </div>

      <div class="col-md-6">
        <nav aria-label="Page navigation example">
          <ul class="pagination">
            <li class="page-item"><a class="page-link" href="#"><</a></li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">></a></li>
          </ul>
        </nav>
      </div>
    </div>
  </main>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
  <iframe class="iframeFooter" id="footer" src="footer.html" frameborder="0"></iframe>
</body>
</html>
  
