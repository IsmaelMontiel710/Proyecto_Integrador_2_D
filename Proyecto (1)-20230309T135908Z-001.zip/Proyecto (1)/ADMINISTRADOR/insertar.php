<?php
    $con=mysqli_connect('localhost','root','','posts') or die('Error en la conexion servidor');
    $sql="INSERT INTO Post VALUES (null,'".$_POST["Titulo"]."','".$_POST["Texto"]."','".$_POST["Autor"]."',null)";
    $resultado=mysqli_query($con,$sql) or die('Erorr en el query database');
    mysqli_close($con);
    
    echo 'El Titulo ingresado es: '.$_POST["Titulo"];
    echo 'El Texto ingresado es: '.$_POST["Texto"];
    echo 'El Autor ingreso: '.$_POST["Autor"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>entregado</title>
</head>
<body>
    <form action="ejemplo.php">
        <button type="submit" class="btn btn-info">
            <i class='bx bx-menu' id="btn" ></i>
            <span class="Creap">crear post</span>
        </button>
    </form>
    <form action="../Visitante/visitante.php">
        <button type="submit" class="btn btn-info">
            <i class='bx bx-menu' id="btn" ></i>
            <span class="Vis">Visitar a visitante</span>
        </button>
    </form>
</body>
</html>