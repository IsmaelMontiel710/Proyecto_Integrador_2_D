<?php
    $con=mysqli_connect('localhost','root','','posts') or die('Error en la conexion servidor');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Base de datos</title>
</head>
<body>
  <form action="insertar.php" method="POST">
      <p>Title: <input type="text" name="Titulo" ></p>
      <p>Texto: <input type="text" name="Texto" ></p>
      <p>Autor: <input type="text" name="Autor" ></p>
      <button onclick="alert('Se guardaron los datos')">
        Enviar
      </button>
  </from>
</body>
</html>