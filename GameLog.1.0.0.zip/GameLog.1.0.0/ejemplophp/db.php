<?php


$conn = mysqli_connect(
  'localhost',
  'root',
  '',
  'login-php'
) or die(mysqli_erro($mysqli));

?>
