<?php

include('db.php');

if (isset($_POST['preview'])) {
  $title = $_POST['title2'];
  $subtitle = $_POST['subtitle2'];
  $description = $_POST['description2'];
  $image = addslashes(file_get_contents($_FILES['image2']['tmp_name']));
  $query = "INSERT INTO preview(title2, subtitle2, description2, image2) VALUES ('$title','$subtitle', '$description','$image')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Saved Successfully';
  $_SESSION['message_type'] = 'success';
  header('Location: visual.php');

}

?>