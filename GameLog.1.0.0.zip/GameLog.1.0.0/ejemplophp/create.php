<?php require_once "../Login/controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: login.php');
}
?>
<?php include("db.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Import de Boxicons-->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/5f897f84ba.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Document</title>
    <link rel="stylesheet" href="css/backgroundpost1.css">

</head>
<body>
    <section class="text-center">
        <div class="text">PUBLICACIONES</div>
        <div class="bodytext"></div>
    </section>
    <br>
    <div class="row text-dark">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <table class="table table-bordered text-center border-4 border-warning">
              <thead>
                <tr class="text-light text-uppercase">
                  <th class="col-2">Titulo</th>
                  <th class="col-2">Subtitulo</th>
                  <th class="col-2">Fecha Creacion</th>
                  <th class="col-2">Imagen</th>
                  <th class="col-1">Seccion</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $query = "SELECT * FROM task ORDER BY id DESC";
                $result_tasks = mysqli_query($conn, $query);    
                while($row = mysqli_fetch_assoc($result_tasks)) { ?>
                <tr>
                  <td><?php echo $row['title']; ?></td>
                  <td><?php echo $row['subtitle']; ?></td>
                  <td><?php echo $row['created_at']; ?></td>
                  <td class="imga text-center mt-1"><?php echo $row['image']="<img width='auto' height='150px' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?></td>
                  <td><?php echo $row['seccion']; ?></td>
                </tr>
                <?php } ?>
                <?php
                $query = "SELECT * FROM xbox ORDER BY id DESC";
                $result_tasks = mysqli_query($conn, $query);    
                while($row = mysqli_fetch_assoc($result_tasks)) { ?>
                <tr>
                  <td><?php echo $row['title']; ?></td>
                  <td><?php echo $row['subtitle']; ?></td>
                  <td><?php echo $row['created_at']; ?></td>
                  <td class="imga text-center mt-1"><?php echo $row['image']="<img width='auto' height='150px' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?></td>
                  <td><?php echo $row['seccion']; ?></td>
                </tr>
                <?php } ?>
                <?php
                $query = "SELECT * FROM play ORDER BY id DESC";
                $result_tasks = mysqli_query($conn, $query);    
                while($row = mysqli_fetch_assoc($result_tasks)) { ?>
                <tr>
                  <td><?php echo $row['title']; ?></td>
                  <td><?php echo $row['subtitle']; ?></td>
                  <td><?php echo $row['created_at']; ?></td>
                  <td class="imga text-center mt-1"><?php echo $row['image']="<img width='auto' height='150px' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?></td>
                  <td><?php echo $row['seccion']; ?></td>
                </tr>
                <?php } ?>
                <?php
                $query = "SELECT * FROM nintendo ORDER BY id DESC";
                $result_tasks = mysqli_query($conn, $query);    
                while($row = mysqli_fetch_assoc($result_tasks)) { ?>
                <tr>
                  <td><?php echo $row['title']; ?></td>
                  <td><?php echo $row['subtitle']; ?></td>
                  <td><?php echo $row['created_at']; ?></td>
                  <td class="imga text-center mt-1"><?php echo $row['image']="<img width='auto' height='150px' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?></td>
                  <td><?php echo $row['seccion']; ?></td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
      </div>
    </div>
    <script>var exampleModal = document.getElementById('exampleModal')
    exampleModal.addEventListener('show.bs.modal', function (event) {
    // Button that triggered the modal
    var button = event.relatedTarget
    // Extract info from data-bs-* attributes
    var recipient = button.getAttribute('data-bs-whatever')
    // If necessary, you could initiate an AJAX request here
    // and then do the updating in a callback.
    //
    // Update the modal's content.
    var modalTitle = exampleModal.querySelector('.modal-title')
    var modalBodyInput = exampleModal.querySelector('.modal-body input')

    modalTitle.textContent = 'NUEVA PUBLICACIÓN' //+ recipient
    //modalBodyInput.value = recipient
    })</script>

    </nav>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</body>
</html>
