<?php require_once "../Login/controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: login.php');
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title>Administrador</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/create.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
        <i class='bx bxs-game icon'></i>
        <div class="logo_name">GameLog</div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="../Login/registroadmin.php">
          <i class="bi bi-person-plus-fill"></i>
          <span class="links_name">AGREGAR</span>
        </a>
        <span class="tooltip">AGREGAR</span>
      </li>
      <li>
        <a href="posts.php">
          <i class='bx bx-notepad'></i>
          <span class="links_name">PUBLICACIONES</span>
        </a>
        <span class="tooltip">PUBLICACIONES</span>
      </li>
      <li>
        <a href="xbox/posts_xbox.php">
          <i class="bi bi-xbox"></i>
          <span class="links_name">XBOX</span>
        </a>
        <span class="tooltip">XBOX</span>
      </li>
      <li>
        <a href="pc/posts_pc.php">
          <i class="bi bi-pc-display"></i>
          <span class="links_name">PC</span>
        </a>
        <span class="tooltip">PC</span>
      </li>
      <li>
        <a href="play/posts_play.php">
          <i class="bi bi-playstation"></i>
          <span class="links_name">PLAYSTATION</span>
        </a>
        <span class="tooltip">PLAYSTATION</span>
      </li>
      <li>
        <a href="xbox/posts_xbox.php">
          <i class="bi bi-nintendo-switch"></i>
          <span class="links_name">NINTENDO</span>
        </a>
        <span class="tooltip">NINTENDO</span>
      </li>
      <li>
        <a href="modal.php">
          <i class='bx bxs-user-rectangle'></i>
          <span class="links_name">MODO VISITANTE</span>
        </a>
        <span class="tooltip">VISITANTE</span>
      </li>
      <li class="profile">
        <div class="profile-details">
          <div class="name_job">
            <div class="name">ADMINISTRADOR</div>
            <div class="job"><?php echo $fetch_info['name'] ?></div>
          </div>
        </div>
        <i>
          <form action="../Login/cerrar_sesion.php ">
            <button class='bx bx-log-out' id="log_out"></button>
          </form>
        </i>
      </li>
    </ul>
  </div>
  <section class="home-section">
    <iframe class="creating" src="create.php" frameborder="0"></iframe> <!---//footer-->
  </section>

<script>
  let sidebar = document.querySelector(".sidebar");
  let closeBtn = document.querySelector("#btn");
  let searchBtn = document.querySelector(".bx-search");

  closeBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("open");
});
  </script>
</body>
</html>