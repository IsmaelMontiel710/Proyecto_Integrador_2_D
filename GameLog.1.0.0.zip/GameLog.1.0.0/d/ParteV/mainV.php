<main>
  <?php
      include("../ejemplophp/db.php");
      $title = '';
      $description= '';

      if  (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "SELECT * FROM task WHERE id=$id";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
          $row = mysqli_fetch_array($result);
          $title = $row['title'];
          $subtitle = $row['subtitle'];
          $description = $row['description'];
          $image = $row['image'];
        }
      }
  ?>
  
  <div class="pe">
    <h1 class="text-center">Visualizacion en los Posts</h1>
  </div>
  <div class="text-center text-light">
    <!--el texto de la post-->
    <h1><?php echo $title; ?></h1>
    <h3><?php echo $subtitle; ?></h3>
    <?php
      if  (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "SELECT * FROM task WHERE id=$id";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
          $row = mysqli_fetch_array($result);
          $title = $row['title'];
          $description = $row['description'];
          $image = $row['image'];
        }
      }
    ?>
    <?php echo $row['image']="<img  width='300px' height='500px' class='container' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
    <p><?php echo $description;?></p>
  </div>
</main>
<br>