<?php 
    include_once 'classes/db.php';
    $con = DB::getConn();
?>