<?php require_once "../../Login/controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: login.php');
}
?>
<?php include("../db.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Import de Boxicons-->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/5f897f84ba.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Document</title>
    <link rel="stylesheet" href="../css/backgroundpost1.css">

</head>
<body>
    <section>
        <div class="text">PUBLICACIONES</div>
        <div class="bodytext"></div>
    </section>

    <p class="text-center">
      <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">
        CREAR PUBLICACION
      </button>
    </p>

    <div style="min-height: 120px;">
      <div class="collapse collapse-horizontal" id="collapseWidthExample">
        <div class="card card-body" style="width: 300px;">
        <div class="form-group ">

          <div class="btn-group me-2" role="group" aria-label="First group">
            <div class="btn-pos d-flex justify-content-around btn m-6">
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal"><img src="../img/nin.png" width="50px"></button>
            </div>

            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" style="max-width: 35%"; role="document">
                <div class="modal-content">
                <div class="modal-body ">
                    <form action="../save_task.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="message-text" class="form-label">TITULO:</label>
                            <input type="text" name="title" class="form-control" autofocus required>
                        </div>
                        <div class="form-group">
                            <label class="form-label mt-2">SUBTITULO:</label>
                            <input type="text" name="subtitle" class="form-control" autofocus  required>
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="form-label">DESCRIPCION:</label>
                            <textarea name="description" rows="2" class="form-control" required></textarea>
                        </div>
                        <div class="">
                          <p class="text-dark">Ingrese una Imagen <input type="file" name="image" required>
                          </p>
                        </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">CANCELAR
                                </button>
                                <form>
                                    <input type="submit" name="save_task" class="btn btn-outline-success" value="GUARDAR">
                                </form>
                            </div>
                        </div>
                  </form>
                </div>
              </div>
            </div>

          </div>
          </div>
        </div>
      </div>
    </div>

    <br>
    <div class="row text-dark">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <table class="table table-bordered text-center border-4 border-warning">
              <thead>
                <tr class="text-light text-uppercase">
                  <th class="col-2">Titulo</th>
                  <th class="col-2">Subtitulo</th>
                  <th class="col-2">Fecha Creacion</th>
                  <th class="col-2">Imagen</th>
                  <th class="col-1">Seccion</th>
                  <th class="col-3">Accion</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $query = "SELECT * FROM nintendo ORDER BY id DESC";
                $result_tasks = mysqli_query($conn, $query);    
                while($row = mysqli_fetch_assoc($result_tasks)) { ?>
                <tr>
                  <td><?php echo $row['title']; ?></td>
                  <td><?php echo $row['subtitle']; ?></td>
                  <td><?php echo $row['created_at']; ?></td>
                  <td class="imga text-center mt-1"><?php echo $row['image']="<img width='auto' height='150px' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?></td>
                  <td><?php echo $row['seccion']; ?></td>
                  <td class="text-center">
                    <a href="../edit.php?id=<?php echo $row['Id']?>" class="btn btn-outline-success mt-2 mb-1">
                      <i class="fas fa-marker"></i>
                    </a>
                    <a href="delete_task_nin.php?id=<?php echo $row['Id']?>" class="btn btn-outline-danger mt-2 mb-1">
                      <i class="far fa-trash-alt"></i>
                    </a>
                    <a href="../d/Vision.php?id=<?php echo $row['Id']?>" class="btn btn-outline-primary mt-2 mb-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                        <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                        <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                      </svg>
                    </a>
                  </td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
      </div>
    </div>
    <script>var exampleModal = document.getElementById('exampleModal')
    exampleModal.addEventListener('show.bs.modal', function (event) {
    // Button that triggered the modal
    var button = event.relatedTarget
    // Extract info from data-bs-* attributes
    var recipient = button.getAttribute('data-bs-whatever')
    // If necessary, you could initiate an AJAX request here
    // and then do the updating in a callback.
    //
    // Update the modal's content.
    var modalTitle = exampleModal.querySelector('.modal-title')
    var modalBodyInput = exampleModal.querySelector('.modal-body input')

    modalTitle.textContent = 'NUEVA PUBLICACIÓN' //+ recipient
    //modalBodyInput.value = recipient
    })</script>

    </nav>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</body>
</html>
