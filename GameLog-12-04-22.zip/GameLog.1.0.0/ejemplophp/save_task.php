<?php

include('db.php');

if (isset($_POST['save_task'])) {
  $title = $_POST['title'];
  $subtitle = $_POST['subtitle'];
  $description = $_POST['description'];
  $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
  $query = "INSERT INTO task(title, subtitle, description, image, seccion) VALUES ('$title','$subtitle', '$description','$image','Pc')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Saved Successfully';
  $_SESSION['message_type'] = 'success';
  header('Location: create_pc.php');

}


if (isset($_POST['save_task_xbox'])) {
  $title = $_POST['title'];
  $subtitle = $_POST['subtitle'];
  $description = $_POST['description'];
  $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
  $query = "INSERT INTO xbox(title, subtitle, description, image, seccion) VALUES ('$title','$subtitle', '$description','$image','Xbox')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Saved Successfully';
  $_SESSION['message_type'] = 'success';
  header('Location: create_xbox.php');

}


if (isset($_POST['save_task_play'])) {
  $title = $_POST['title'];
  $subtitle = $_POST['subtitle'];
  $description = $_POST['description'];
  $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
  $query = "INSERT INTO play(title, subtitle, description, image,seccion) VALUES ('$title','$subtitle', '$description','$image','play')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Saved Successfully';
  $_SESSION['message_type'] = 'success';
  header('Location: play/create_play.php');

}

if (isset($_POST['save_task_nintendo'])) {
  $title = $_POST['title'];
  $subtitle = $_POST['subtitle'];
  $description = $_POST['description'];
  $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
  $query = "INSERT INTO nintendo(title, subtitle, description, image,seccion) VALUES ('$title','$subtitle', '$description','$image','Nintendo')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Saved Successfully';
  $_SESSION['message_type'] = 'success';
  header('Location: create_nintendo.php');

}

?>
