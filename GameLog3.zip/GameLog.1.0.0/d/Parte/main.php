<?php include("../ejemplophp/db.php"); ?>  
<br>
<div class="p-4 p-md-5 mb-4 text-white rounded back">
  <div class="col-6 px-0">
  <h1 class="display-4 fst-italic">La comunidad menos toxica que existe XD</h1>
  <p class="lead my-3">Noticias que blindad a los gamers informacion relevante sobre nuevos lanzamientos, reportes y avances tecnologicos con relacion a nuestra comunidad tranquila y apacionada.</p>
  <p class="lead mb-0"><a href="../Login/login.php" class="text-white fw-bold">Unete a la Comunidad...</a></p>
  </div>
</div>
<div class="row g-5">
    <div class="col-md-8">
      <h3 class="pb-4 mb-4 fst-italic border-bottom">
        Lo mas Semanal
      </h3>

      <article class="blog-post">
        <?php
          $query = "SELECT * FROM task ORDER BY id DESC LIMIT 5";
          $result_tasks = mysqli_query($conn, $query);    
          while($row = mysqli_fetch_assoc($result_tasks)) { ?>
        <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
          <div class="col p-4 d-flex flex-column position-static">
            <strong class="d-inline-block mb-2 text-primary">
              <?php echo $row['seccion']?>
            </strong>
            <h3 class="mb-0"><?php echo $row['title']?></h3>
            <div class="mb-1 text-muted"><?php echo $row['created_at']; ?></div>
            <p class="card-text mb-auto"><?php echo $row['subtitle']; ?></p>
            <a href="#" class="stretched-link">Continuar leyendo...</a>
          </div>
          <div class="col-auto d-lg-block">
            <?php echo $row['image']="<img width='auto' height='250px' src='data:image/jpg;base64,".base64_encode($row['image'])."'>";?>
          </div>
        </div>
        <?php
        }
        ?>
      </article>

      <article class="blog-post">
      </article>

      <article class="blog-post">
      </article>

    </div>

    <div class="col-md-4 ">
      <br>
      <div class="card">
        <div class="card-body">
          <h4 class="">Soporte de las secciones</h4>
          <ol class="list-unstyled">
            <li><a href="https://support.xbox.com/es-MX/">Xbox</a></li>
            <li><a href="#">Play Station</a></li>
            <li><a href="#">Nintendo</a></li>
            <li><a href="#">Pc</a></li>
          </ol>
        </div>
      </div>
      <br>
    </div>
  </div>