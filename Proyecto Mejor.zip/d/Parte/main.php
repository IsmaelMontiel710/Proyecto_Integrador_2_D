<main><!--es el contenido de toda la pagina principal-->
  <div class="col-12"><!--con el div contengo todo el carrusel que es lo que se mueve-->
    <div id="myCarousel" class="carousel slide" data-bs-ride="carousel"><!--desde aqui empieza el carrusel-->
        <div class="carousel-indicators"><!--es para que se mueva solo con la clase active es el que inicia cuando se ejcuta pa pagina-->
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" aria-label="Slide 1" class="active"></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3" class=""></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="3" aria-label="Slide 4" class="" aria-current="true"></button>
        </div>
        <!--Es todo el contendio que tiene la pagina-->
        <div class="carousel-inner">
          <!--tienen un espacio para diferenciar de otro-->
          <div class="carousel-item active container img">
            <a href="Publicaciones.php"><!--Cuando el mause se acerca a la imagen le pude presionar y es un link a la publicacion-->
              <figure class="zoomca "><!--la clase zoomca es para que la imagen que estoy llamando haga zoom-->
                <img class="ma"src="img/MarioBros.jpg" alt="">
              </figure>
            </a>
            <div class="carousel-caption text-center">
                <h2 >Mario Bros La Pelicula</h2>
                <p >Esta Cada Vez mas cercas de lo esperado</p>
            </div>
          </div>

          <div class="carousel-item">
            <a href="Publicaciones.php">
              <figure class="zoomca ">
                <img class="ma"src="img/MarioBros.jpg" alt="">
              </figure>
            </a>
            <div class="carousel-caption text-center">
                <h2 >Mario Bros La Pelicula</h2>
                <p >Esta Cada Vez mas cercas de lo esperado</p>
            </div>
          </div>

          <div class="carousel-item">
            <a href="Publicaciones.php">
              <figure class="zoomca ">
                <img class="ma"src="img/MarioBros.jpg" alt="">
              </figure>
            </a>
            <div class="carousel-caption text-center">
                <h2 >Mario Bros La Pelicula</h2>
                <p >Esta Cada Vez mas cercas de lo esperado</p>
            </div>
          </div>

          <div class="carousel-item">
            <a href="Publicaciones.php">
              <figure class="zoomca ">
                <img class="ma"src="img/MarioBros.jpg" alt="">
              </figure>
            </a>
            <div class="carousel-caption text-center">
                <h2 >Mario Bros La Pelicula</h2>
                <p >Esta Cada Vez mas cercas de lo esperado</p>
            </div>
          </div>

        </div>

        <!--Son los botones de accion al cambiar de pagina haga la funcion(funcion de boostrap)-->
        <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden"></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden"></span>
        </button>
    </div>
    <br>
  </div>
  <!--es el tabla se podria decir de las publicaciones de abajo del carrusel-->
  <div class="row container">
    <div class="col-1"><!--es el epacio entre una-->
    </div>
    <div class="col-2 text-center"><!--es como un cuadro que tiene 2 columnas -->
      <div class="col-11 bg-light text-dark rounded borde"><!--de esas 2 columas esta dividido en 11 columnas con sus respectivos bordes-->
        <br>
        <a href="Publicaciones.php"><!--cuando se acerca el mouse es un link y hace zoom-->
          <figure class="zoom">
            <img src="img/MarioBros.jpg" alt="">
          </figure>
        </a>
        <h2 class="text">Mario Bros La Pelicula</h2><!--el titulo-->
        <p class="">Esta Cada Vez mas cercas de lo esperado</p><!--texto-->
        <div class="text-center">
          <a href="#" class="btn btn-outline-dark">ver mas...</a><!--todavia no lo manda a ningun link-->
        </div>
        <br>
      </div>
    </div>

    <div class=" col-2 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <a href="Publicaciones.php">
          <figure class="zoom">
            <img src="img/MarioBros.jpg" alt="">
          </figure>
        </a>
        <h2 class="text">Mario Bros La Pelicula</h2>
        <p class="">Esta Cada Vez mas cercas de lo esperado</p>
        <div class="text-center">
          <a href="#" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>

    <div class=" col-2 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <br>
        <a href="Publicaciones.php">
          <figure class="zoom">
            <img src="img/MarioBros.jpg" alt="">
          </figure>
        </a>
        <h2 class="text">Mario Bros La Pelicula</h2>
        <p class="">Esta Cada Vez mas cercas de lo esperado</p>
        <div class="text-center">
          <a href="#" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>

    <div class="col-2 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <a href="Publicaciones.php">
          <figure class="zoom">
            <img src="img/MarioBros.jpg" alt="">
          </figure>
        </a>
        <h2 class="text">Mario Bros La Pelicula</h2>
        <p class="">Esta Cada Vez mas cercas de lo esperado</p>
        <div class="text-center">
          <a href="#" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>

    <div class="col-2 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <br>
        <a href="Publicaciones.php">
          <figure class="zoom">
            <img src="img/MarioBros.jpg" alt="">
          </figure>
        </a>
        <h2 class="text">Mario Bros La Pelicula</h2>
        <p class="">Esta Cada Vez mas cercas de lo esperado</p>
        <div class="text-center">
          <a href="#" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
  </div>
  <div class="col-1">
  </div>
</main>
<br>