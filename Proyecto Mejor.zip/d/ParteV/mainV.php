<?php
    $con=mysqli_connect('localhost','root','','posts') or die('Error en la conexion servidor');
?>
<main>
  <div class="pe">
    <h1 class="text-center">Visualizacion del Carrusel</h1>
  </div>
  <div class="col-12">
    <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" aria-label="Slide 1" class="active"></button>
        </div>
        
        <div class="carousel-inner">
          <div class="carousel-item active container img">
            <a href="Visitante.php">
              <figure class="zoomca ">
                <?php
                  $sql = "SELECT * FROM post ORDER BY id DESC LIMIT 1";
                  $result=mysqli_query($con,$sql);
                  $mos=mysqli_fetch_array($result);
                    echo $mos['Imagen']="<img class='ma' src='data:image/jpg;base64,".base64_encode($mos['Imagen'])."'>";
                ?>
              </figure>
            </a>
            <div class="carousel-caption text-center">
                <h1><?php echo $mos['Titulo']?></h1>
                <h2><?php echo $mos['Autor']?></h2>
            </div>
          </div>
        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden"></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden"></span>
        </button>
    </div>
    <br>
  </div>
  <div class="pe">
    <h1 class="text-center">Visualizacion de la caja</h1>
  </div>
  <div class="row container ">
    <div class="col-4">
    </div>

    <div class="col-2 text-center Container">
      <div class="col-11 bg-light text-dark rounded borde">
        <br>
        <a href="Visitante.php">
          <figure class="zoom">
            <?php
              $sql = "SELECT * FROM post ORDER BY id DESC LIMIT 1";
              $result=mysqli_query($con,$sql);
              $mos=mysqli_fetch_array($result);
              echo $mos['Imagen']="<img class='ma' src='data:image/jpg;base64,".base64_encode($mos['Imagen'])."'>";
            ?>
          </figure>
        </a>
        <h2><?php echo $mos['Titulo']?></h2>
        <p><?php echo $mos['Autor']?></p>
        <div class="text-center">
          <a href="#" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>
    
    <div class=" col-2 text-center">
      <div class="col-11 bg-light text-dark rounded borde">
        <a href="Visitante.php">
          <figure class="zoom">
            <?php
              $sql = "SELECT * FROM post ORDER BY id DESC LIMIT 1";
              $result=mysqli_query($con,$sql);
              $mos=mysqli_fetch_array($result);
              echo $mos['Imagen']="<img class='ma' src='data:image/jpg;base64,".base64_encode($mos['Imagen'])."'>";
            ?>
          </figure>
        </a>
        <h2><?php echo $mos['Titulo']?></h2>
        <p><?php echo $mos['Autor']?></p>
        <div class="text-center">
          <a href="#" class="btn btn-outline-dark">ver mas...</a>
        </div>
        <br>
      </div>
    </div>
    <div class="col-1"></div>
  </div>
  <div class="pe">
    <h1 class="text-center">Visualizacion en los Posts</h1>
  </div>
  <div class="text-center text-light">
    <h1><?php echo $mos['Titulo']?></h1>
  </div>
</main>
<br>