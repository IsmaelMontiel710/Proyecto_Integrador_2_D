<?php
    $con=mysqli_connect('localhost','root','','posts') or die('Error en la conexion servidor');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!--<title> Responsive Sidebar Menu  | CodingLab </title>-->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="../Visitante/animaciones.css">
    <link rel="stylesheet" type="text/css" href="css/interfaces.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar cmd-4">
    <div class="logo-details">
        <i class='bx  icon personaje'></i>
        <div class="logo_name">GameLog</div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="#">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <li>
       <a href="Visitante">
         <i class='bx bx-user' ></i>
         <span class="links_name">User</span>
       </a>
       <span class="tooltip">User</span>
     </li>
     <li>
       <a href="#">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Comments</span>
       </a>
       <span class="tooltip">Comments</span>
     </li>
     <li>
       <a href="#">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Analytics</span>
       </a>
       <span class="tooltip">Analytics</span>
     </li>
     <li>
       <a href="#">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Posts</span>
       </a>
       <span class="tooltip">Posts</span>
     </li>
     <li>
       <a href="#">
         <i class='bx bx-cog' ></i>
         <span class="links_name">Setting</span>
       </a>
       <span class="tooltip">Setting</span>
     </li>
     <li class="profile">
         <div class="profile-details">
           <!--<img src="profile.jpg" alt="profileImg">-->
           <div class="name_job">
             <div class="name">USER</div>
             <div class="job">ADMIN</div>
           </div>
            <i >
              <!--cuando se ejecute la accion from me mandara a llamar a la carpeta que se escribio-->
              <form action="Visitante">
                <button target="_blank" class='bx bx-log-out' id="log_out">
                </button>
              </form>
            </i>
         </div>
     </li>
    </ul>
  </div>
  <section class="home-section">
    <div class="text">DASHBOARD</div>
    <div class="cards">
      <div class="card">
        <div class="card-content">
            <?php
            $sql="SELECT * FROM Post ORDER BY id DESC LIMIT 1";
            $result=mysqli_query($con,$sql);
            $mos=mysqli_fetch_array($result)
            ?>
            <tr>
                <td><?php echo $mos['ID']?></td>
            </tr>
          <div class="card-name">POSTS</div>
        </div>
        <i class='bx bxs-notepad icon' style='color:#ffffff'  >
        <box-icon name='like' type='solid' color='#ffffff' >
          <i class="fas fa-briefcase-medical"></i>
        </i>
      </div>
      <div class="card">
        <div class="card-content">
          <div class="number">105</div>
          <div class="card-name">LIKE</div>
        </div>
        <i class='bx bxs-like icon' style='color:#ffffff'  >
          <i class="fas fa-briefcase-medical"></i>
        </i>
      </div>
      <div class="card">
        <div class="card-content">
          <div class="number">8</div>
          <div class="card-name">NEW SUSCRIPTORS</div>
        </div>
        <i class='bx bx-line-chart icon' style='color:#ffffff'  >
          <i class="fas fa-briefcase-medical"></i>
        </i>
      </div>
      <div class="card">
        <div class="card-content">
          <div class="number">45,000</div>
          <div class="card-name">SUSCRIPTORS</div>
        </div>
        <i class='bx bx-bar-chart icon' style='color:#ffffff'  >
          <i class="fas fa-briefcase-medical"></i>
        </i>
      </div>
    </div>
    <div class="tables cmd-7">
      <div class="last-appointments">
        <div class="heading">
          <h2>MOST RENCENTLY POSTS</h2>
          
          
        </div>
        <!--Se creara la tabla-->
        <table>
            <form action="ejemplo.php">
              <button type="submit" class="btn btn-info">
                <i class='bx bx-menu' id="btn" ></i>
                <span class="Crea">Crear</span>
              </button>
            </form>
          <a href="#" class="btn">View All</a>
            <tr>
                <td>Titulo</td>
                <td>Titulo</td>
                <td>Autor</td>
                <td>Fecha  Hora</td>
            </tr>
            <?php
            $sql="SELECT * FROM Post";
            $result=mysqli_query($con,$sql);
            while($mos=mysqli_fetch_array($result))
            {
            ?>
            <tr>
                <td><?php echo $mos['ID']?></td>
                <td><?php echo $mos['Titulo']?></td>
                <td><?php echo $mos['Autor']?></td>
                <td><?php echo $mos['Fecha']?></td>
            </tr>
            <?php
            }
            ?>
        </table>
      </div>
    </div>
    <section>
      <div class="personaje"></div>
    </section>
  </section>
<script>
  let sidebar = document.querySelector(".sidebar");
  let closeBtn = document.querySelector("#btn");
  let searchBtn = document.querySelector(".bx-search");

  closeBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("open");
});
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  
</body>
</html>

