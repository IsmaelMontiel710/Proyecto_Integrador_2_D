<?php require_once "../Login/controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitante</title>
    <link rel="stylesheet" href="../d/css/fondo-texto.css">
    <link rel="stylesheet" href="https://bootswatch.com/4/yeti/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/5f897f84ba.js" crossorigin="anonymous"></script>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body class="body">
    <?php
    include("db.php");
    $title = '';
    $description= '';

    if  (isset($_GET['id'])) {
      $id = $_GET['id'];
      $query = "SELECT * FROM task WHERE id=$id";
      $result = mysqli_query($conn, $query);
      if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);
        $title = $row['title'];
        $subtitle= $row['subtitle'];
        $description = $row['description'];
        $image = $row['image'];
      }
    }

    if (isset($_POST['update'])) {
      $id = $_GET['id'];
      $title= $_POST['title'];
      $subtitle= $_POST['subtitle'];
      $description = $_POST['description'];
      $query = "UPDATE task set title = '$title', subtitle = '$subtitle', description = '$description' WHERE id=$id";
      mysqli_query($conn, $query);
      $_SESSION['message'] = 'Task Updated Successfully';
      $_SESSION['message_type'] = 'warning';
      header('Location: create.php');
    }

    ?>
    <br>
    <div class="">
      <div class="row">
        <div class="col-md-5 mx-auto">
          <div class="card card-body">
          <form action="edit.php?id=<?php echo $_GET['id']; ?>" method="POST" enctype="multipart/form-data">
            <h1 class="text-center">EDITAR PUBLICACION</h1>
            <div class="form-group">
              <input name="title" type="text" class="form-control" value="<?php echo $title; ?>" placeholder="Update Title">
            </div>
            <div class="form-group">
              <input name="subtitle" type="text" class="form-control" value="<?php echo $subtitle; ?>">
            </div>
            <div class="form-group">
            <textarea name="description" class="form-control" cols="30" rows="10"><?php echo $description;?></textarea>
            </div>
            <div>
              <div class="accordion accordion-flush" id="accordionFlushExample">
                <div class="accordion-item">
                  <h2 class="accordion-header" id="flush-headingOne">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                        EDITAR IMAGEN
                        <?php
                            if  (isset($_GET['id'])) {
                              $id = $_GET['id'];
                              $query = "SELECT * FROM task WHERE id=$id";
                              $result = mysqli_query($conn, $query);
                              if (mysqli_num_rows($result) == 1) {
                                $row = mysqli_fetch_array($result);
                                $image = $row['image'];
                              }
                            }
                    
                            if (isset($_POST['update'])) {
                              $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
                              $query = "UPDATE task set image = '$image' WHERE id=$id";
                              mysqli_query($conn, $query);
                              $_SESSION['message'] = 'Task Updated Successfully';
                              $_SESSION['message_type'] = 'warning';
                              header('Location: create.php');
                            }
                        ?>
                    </button>
                  </h2>
                  <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body">
                      <div class="">
                        <p class="text-dark">Ingrese una Imagen <input type="file" name="image"></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <br>
            <br>
            <button class=" btn btn-success" name="update">
              GUARDAR
            </button>
            <a href="create.php" class="btn btn-primary">REGRESAR</a>
          </form>
          </div>
        </div>
      </div>
    </div>

    <div class="espacio"></div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>